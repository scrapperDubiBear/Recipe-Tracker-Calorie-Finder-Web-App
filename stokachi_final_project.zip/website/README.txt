Before running the application, follow the below steps to import the database:

1. Create a mongoDB database named 'recipeDB'. 
2. Import the collection within 'collectionsData' folder into mongoDB. 
3. Do NOT rename any of the files in the 'collectionsData' folder.
4. Name each collection in the 'recipeDB' database the same name as the file from which
    the data is being imported. 
 

Running the application:
1. Run the main.py file and copy the URL to the browser. 