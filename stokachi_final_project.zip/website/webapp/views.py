'''
    Defines the URLs of the pages in the site and the associated action.

    Methods in the page:
        0. getNextID()
        1. home()  
        2. add()
        3. actions()
        4. editRecipe()

        5. tracker()
        6. addEntry()
        7. editEntry()
        8. deleteEntry()

        9. findCalories()
        10. maxRepeatedMeal()
        11. stats() -> Extra credit complex query involving 4 collections
'''

from flask import Blueprint, render_template, request, flash, jsonify
from datetime import datetime
import pymongo


#print(mongo)

views = Blueprint('views', __name__)


from . import db
#print(db)
#print(db.ingredient)
#print(db.ingredient.find_one())

#Increase everytime new recipe is added, do NOT decrease when deleted to avoid dupicate keys
def getNextID(collection_name):
    ''' Helper method to get _id attribute such that DuplicateKeyError is prevented 
        for mealTracker, recipe and ingredient collections. '''
    
    counterDocument = db.counters.find_one_and_update(
            {"_id": collection_name},
            {"$inc": {"seq": 1}},
            return_document=True,
            upsert=True
    )
    return counterDocument["seq"]


@views.route('/', methods = ['GET', 'POST'])
def home(calories=None, recipeCal=None):
    if request.method == 'POST':
        if request.form.get("form_id") == 'deleteRecipe':
            rid = int(request.form.get('recipe_id'))

            #delete from inRecipe
            db.inRecipe.delete_many({'rid': rid})

            #delete from mealTracker 
            db.mealTracker.delete_many({'recipeID': rid})

            #delete from recipe
            db.recipe.delete_one({'_id': rid})

    ingredientList = db.ingredient.find({}, {'calories': 0})
    ingredientList = [x for x in ingredientList]
    #print(ingredientList)
    
    ##########################################################################################
    ''' COMPLEX QUERY-1: 
        SHOW RECIPE
        
        RETURNS RECIPE NAME, ALONG WITH 
        INGREDIENTS, QTY, UNITS AND INSTRUCTIONS
        
        TABLES USED: recipe(for rname, instructions), inRecipe (QTY, UNITS), ingredient (for ingredients)'''
    
    result = db.recipe.aggregate([
    {
    "$lookup": {
      "from": "inRecipe",
      "localField": "_id",
      "foreignField": "rid",
      "as": "recipe_ingredients"
    }
    },
    {
    "$unwind": "$recipe_ingredients"
    },
    {
    "$lookup": {
      "from": "ingredient",
      "localField": "recipe_ingredients.id",
      "foreignField": "_id",
      "as": "ingredient_info"
    }
    },
    {
    "$project": {
      "rname": 1,
      "instructions": 1,
      "ingredient": "$ingredient_info.name",
      "quantity": "$recipe_ingredients.quantity",
      "units": "$recipe_ingredients.units"
    }
    },
    {
    "$group": {
      "_id": {
        "_id": "$_id",
        "rname": "$rname",
        "instructions": "$instructions"
      },
      "ingredients": {
        "$push": {
          "name": "$ingredient",
          "quantity": "$quantity",
          "units": "$units"
        }
      }
    }
    },
    {
    "$project": {
      "_id": "$_id._id",
      "rname": "$_id.rname",
      "instructions": "$_id.instructions",
      "ingredients": 1
    }
    },
    {
    "$sort": {
      "_id": 1
    }
    }
    ])
    result = [y for y in result]

    #Uncomment to print all items of result list
    for item in result:
        print(item)
        print()
    #######################################################################################
    lenR = len(result)

    if lenR != 0:
        if calories is not None:
            result = recipeCal
        return render_template("home.html", lenR=lenR, recipeInfo=result, calories=calories)
     #Print that there are no recipes and ask the user to add recipes and check back later.

    return render_template("home.html", lenR=lenR, calories=calories)


@views.route('/add', methods = ['GET', 'POST'])
def add(flag=1):
    ingredientList = db.ingredient.find({}, {'calories': 0})
    ingredientList = [x for x in ingredientList]
    #print(ingredientList) 

    
    return render_template("add.html", ingredientList = ingredientList)


@views.route('/actions', methods = ['POST'])
def actions():
    ingredientList = db.ingredient.find({})
    ingredientList = [x for x in ingredientList]
    lastIngredient = len(ingredientList)

    recipeList = db.recipe.find({})
    recipeList = [x for x in recipeList]
    lastRecipe = len(recipeList)

    if request.method == 'POST':
        #print('Inside POST of ACTIONS')
        if request.form.get("form_id") == 'addIngredient':
            id = getNextID("ingredient")
            name = request.form.get("name")
            calories = request.form.get("calories")
            newRecord = {"_id": id, "name": name, "calories": calories}
            db.ingredient.insert_one(newRecord)
            flash('Added new ingredient', category="success")

        elif request.form.get("form_id") == 'editIngredient':
            id = int(request.form.get("toEdit"))
            name = request.form.get("newName")
            calories = request.form.get("calories")

            #either name or calories is present or both are present, if not do not accept the edit.
            #print(id)
            #print(name)
            #print(calories)
            if name == '' and calories == '':
                flash('NO EDITS MADE', category="error")
                print('NO EDITS MADE')
            elif name == '':
                #change calories 
                toEditDoc = {'_id': id}
                editedDoc = {'$set': {'_id': id, 'calories': float(calories)}}
                db.ingredient.update_one(toEditDoc, editedDoc)
                flash('Updated Calories', category="success")
                print('Updated calories')
            elif calories == '':
                #change name 
                toEditDoc = {'_id': id}
                editedDoc = {'$set': {'_id': id, 'name': name}}
                db.ingredient.update_one(toEditDoc, editedDoc)
                flash('Updated Name', category="success")
                print('Updated name')
            else:
                #change calories and name 
                toEditDoc = {'_id': id}
                editedDoc = {'$set': {'_id': id, 'name': name, 'calories': float(calories)}}
                db.ingredient.update_one(toEditDoc, editedDoc)
                flash('Updated Name & Calories', category="success")
                print('Updated name & calories')
            
        elif request.form.get("form_id") == 'deleteIngredient':
            id = int(request.form.get("toDelete"))

            '''
                If the ingredient is being used in an existing recipe, 
                do not delete it. 
            '''
            flag = 0
            inRecipes = [db.inRecipe.find({}, {'_id': 0, 'rid': 0, 'quantity': 0, 'units': 0})]
            inRecipes = [y for x in inRecipes for y in x]

            for item in inRecipes:
                if item['id'] == id:
                    flag = 1
                    break

            if flag:
                flash("CANNOT DELETE THE INGREDIENT: It is used in existing recipe. Delete recipe first.", category="error")
            else:
                db.ingredient.delete_one({'_id': id})
                flash('Deleted ingredient', category="error")
            

        elif request.form.get("form_id") == 'addRecipe':
            rid = getNextID("recipe")
            rname = request.form.get("recipeName")
            ingredient = request.form.getlist("ingredient")
            instructions = request.form.get("instructions")
            qty = request.form.getlist("quantity")
            units = request.form.getlist("units[]")
            #print(units)
            #print(rname)
            #print(ingredient)
            #print(qty)
            #print(instructions)

            #Insert into recipe table: _id, rname, instructions
            db.recipe.insert_one({"_id": rid, "rname": rname, "instructions": instructions})

            #Insert into inRecipe table: RID (rid), id, quantity (qty) 
            records = []
            ln = len(qty)
            idx = 0
            while idx < ln:
                records.append({"rid": rid, "id": int(ingredient[idx]), "quantity": float(qty[idx]), "units": units[idx]})
                idx += 1
            print(records)
            db.inRecipe.insert_many(records)
            flash("Added new recipe", category="success")

        elif request.form.get("form_id") == 'deleteRecipe':
            recipeID = request.form.get("recipe_id")
            print('TO DELETE', recipeID)

            return home()
              
    return add()


@views.route('/editRecipe', methods=['POST'])
def editRecipe():
    if request.method == 'POST':
        if request.form.get("form_id") == 'editRecipe':
            rid = request.form.get("recipe_id")
            rname = request.form.get("rname")
            instr = request.form.get("instr")
            return render_template('editRecipe.html', rid = rid, rname = rname, instr = instr)
        
        elif request.form.get("form_id") == 'edittedVal':
            rid = int(request.form.get("recipe_id"))
            rname = request.form.get("rname")
            instr = request.form.get("instr")
            
            toEditDoc = {'_id': rid}
            editedDoc = {'$set': {'_id': rid, 'rname': rname, 'instructions': instr}}
            db.recipe.update_one(toEditDoc, editedDoc)
            #print('Updated the recipe')
            return home()


@views.route('/tracker', methods=['GET', 'POST'])
def tracker():
    mealTrackerList = db.mealTracker.find({}).sort([('date', pymongo.DESCENDING), ('tag', pymongo.ASCENDING)])
    mealTrackerList = [x for x in mealTrackerList]
    #print(mealTrackerList)
    lenMT = len(mealTrackerList)

    if lenMT != 0:
        entries = [{    
                        '_id': m['_id'],
                        'date': m['date'],
                        'recipeName': [x 
                                       for x in db.recipe.find({'_id': m['recipeID']}, {'_id': 0, 'instructions': 0})],
                        'tag': m['tag']
                    }
                    for m in mealTrackerList]
        #GROUP BY DATE NEXT. -> Not needed

        #recipeList = [y for x in recipeList for y in x]
        print(entries)
        return render_template("tracker.html", lenMT = lenMT, entries = entries)

    return render_template("tracker.html", lenMT = lenMT)


@views.route('/findCalories', methods=['GET', 'POST'])
def findCalories():
    '''
    COMPLEX QUERY-2: FIND CALORIES OF ALL RECIPES 

    RETURNS CALORIE COUNT OF ALL RECIPES BY CALCULATING THE SUM OF CALORIES OF EACH INGREDIENT 
    BASED ON THEIR QUANTITY. 
    (Note: IF UNITS ARE NOT IN 'GRAMS', THEY ARE MULTIPLIED BY A CONVERSION 
    FACTOR TO CONVERT TO GRAMS).

    Tables used: Recipe, inRecipe, Ingredient 
    
    '''

    calories = 1
    if request.method == 'POST':
        if request.form.get("form_id") == 'findCalories':
            
            #COMPLEX QUERY: FIND CALORIES OF ALL RECIPES
            recipeCal = db.recipe.aggregate([
            {
                "$lookup": {
                    "from": "inRecipe",
                    "localField": "_id",
                    "foreignField": "rid",
                    "as": "recipe_ingredients"
                }
            },
            {
                "$unwind": "$recipe_ingredients"
            },
            {
                "$lookup": {
                    "from": "ingredient",
                    "localField": "recipe_ingredients.id",
                    "foreignField": "_id",
                    "as": "ingredient_info"
                }
            },
            {
                "$project": {
                    "rname": 1,
                    "instructions": 1,
                    "ingredient": "$ingredient_info.name",
                    "quantity": "$recipe_ingredients.quantity",
                    "units": "$recipe_ingredients.units",
                    "caloriesPerGram": { "$arrayElemAt": [ "$ingredient_info.calories", 0]},
                    "calories": {
                        "$switch": {
                            "branches": [
                               {
                                    "case": {"$eq": ["$recipe_ingredients.units", "grams"]},
                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                    }]}
                                },
                                {
                                    "case": {"$eq": ["$recipe_ingredients.units", "pounds"]},
                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                    }, 453.59]}
                                },
                                {
                                    "case": {"$eq": ["$recipe_ingredients.units", "millilitre"]},
                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                    }]}
                                },
                                {
                                    "case": {"$eq": ["$recipe_ingredients.units", "tsp"]},
                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                    }, 4.26]}
                                },
                                {
                                    "case": {"$eq": ["$recipe_ingredients.units", "tbsp"]},
                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                    }, 12.78]}
                                },
                                {
                                    "case": {"$eq": ["$recipe_ingredients.units", "slice"]},
                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                    }, 50]}
                                }
                            ],
                            "default": 1
                        }
                    }
                }
            },
            {
                "$group": {
                    "_id": {
                        "_id": "$_id",
                        "rname": "$rname",
                        "instructions": "$instructions"
                    },
                    "ingredients": {
                        "$push": {
                            "name": "$ingredient",
                            "quantity": "$quantity",
                            "units": "$units",
                            "caloriesPerGram": "$caloriesPerGram",
                            "calories": "$calories"
                        }
                    },
                    "totalCalories": {"$sum": "$calories"}
                }
            },
            {
                "$project": {
                    "_id": "$_id._id",
                    "rname": "$_id.rname",
                    "instructions": "$_id.instructions",
                    "ingredients": 1,
                    "totalCalories": {"$round": ["$totalCalories", 2]}
                }
            },
            {
                "$sort": {
                    "_id": 1
                }
            }
        ])

            recipeCal = [x for x in recipeCal]
            #Calculate Calories 
            print(recipeCal)

            return home(calories, recipeCal)


@views.route('/addEntry', methods=['GET', 'POST'])
def addEntry():
    recipeList = db.recipe.find({})
    recipeList = [x for x in recipeList]

    mealTracker = db.mealTracker.find({})
    mealTracker = [x for x in mealTracker]

    currDate = datetime.today().strftime('%Y-%m-%d')

    if request.method == 'POST':
        if request.form.get("form_id") == "mEntry":
            id = getNextID("mealTracker")
            date = request.form.get("entryDate")        #CONVERT TO DATE OBJECT -> No need here, convert when extracting. 
            #dateObj = datetime.date(date).strftime(date, "%Y-%m-%d")
            rid = int(request.form.get("mealEntry"))
            tag = request.form.get("tag")
            record = {'_id': id, 'date': date, 'recipeID': rid, 'tag': tag}

            #If entered date is a FUTURE DATE, do NOT insert to the db. Print MSG.
            if date <= currDate:
                db.mealTracker.insert_one(record)   #See if any error checks are needed
                flash('Entry added', category="success")
            else:
                flash('Invalid Date', category="error")
                print("Invalid DATE")
            
    return render_template("addEntry.html", recipeList = recipeList)


@views.route('/editEntry', methods = ['GET', 'POST'])
def editEntry():
    if request.method == 'POST':
        if request.form.get("form_id") == 'editEntry':
            recipeList = db.recipe.find({})
            recipeList = [x for x in recipeList]

            eid = request.form.get("entry_id")
            #print("ENTRY ID", str(eid))
            date = request.form.get("date")
            rname = request.form.get("recipeName")
            tag = request.form.get("tag")
            return render_template('editEntry.html', recipeList = recipeList, eid = eid, date = date, rname= rname, tag = tag)
        
        elif request.form.get("form_id") == 'edittedVal':
            currDate = datetime.today().strftime('%Y-%m-%d')
            flag = 0        #indicates whether mealEntry was changed. 
            eid = int(request.form.get("entry_id"))
            date = request.form.get("date")
            try:
                rid = int(request.form.get("mealEntry"))
            except ValueError:
                flag = 1
            tag = request.form.get("tag")

            #print("ENTRY ID", eid)

            toEditDoc = {'_id': eid}
            if flag:
                editedDoc = {'$set': {'date': date, 'tag': tag}}
            else:
                editedDoc = {'$set': {'date': date, 'recipeID': rid, 'tag': tag}}
            
            if date > currDate:
                flash("INVALID DATE", category="error")
            else:
                db.mealTracker.update_one(toEditDoc, editedDoc)
            #print('Updated the ENTRY')
            return tracker()
        

@views.route('/deleteEntry', methods=['POST', 'GET'])
def deleteEntry():
    if request.method == 'POST':
            if request.form.get("form_id") == 'deleteEntry':
                eid = request.form.get("entry_id")
                db.mealTracker.delete_one({'_id': int(eid)})
    return tracker()


def maxRepeatedMeal(qResult):
    ''' Helper method to get the recipe information that if most frequently occuring based on 'count' attribute.
        If two or more items have the same count value, all the items are returned. '''

    maxCount = float("-inf")
    meals = []
    for qR in qResult:
        if qR['count'] > maxCount:
            while len(meals):
                meals.pop()
            maxCount = qR['count']
            meals.append(qR)
        elif qR['count'] == maxCount:
            meals.append(qR)
    return meals


@views.route("/stats", methods=['POST', 'GET'])
def stats():
    if request.method == 'POST':
        if request.form.get("form_id") == 'mostConsumedMeal':
            startDate = request.form.get("startDate")
            endDate = request.form.get("endDate")
            print(startDate, endDate)
            
            if startDate == '' and endDate == '':
                flash("Enter 'Start Date' and 'End Date' to begin.", category="error")
            elif startDate == '':
                flash("Enter 'Start Date' to begin.", category="error")
            elif endDate == '':
                flash("Enter 'End Date' to begin.", category="error")
            elif endDate < startDate:
                flash("INVALID DATE: Entered 'Start Date' is after 'End Date'", category="error")
                #print("Invalid Date")
            else: 
                ''' COMPLEX QUERY-3: MOST CONSUMED RECIPES OVER GIVEN DATE & ASSOCIATED TOTAL CALORIES

                    Returns the recipe name, along with associated total calories consumed through it 
                    (i.e., recipe count * recipe calories) and the dates it was consumed on, 
                    along with the count of how many times it was consumed. 

                    
                    Tables used: MealTracker, Recipe, inRecipe, Ingredient
                '''
                result = db.mealTracker.aggregate([
                            {
                                "$match": {
                                    "date": {"$gte": startDate, "$lte": endDate}
                                }
                                
                            },
                            {
                                "$lookup": {
                                    "from": "recipe",
                                    "localField": "recipeID",
                                    "foreignField": "_id",
                                    "as": "recipe_info"
                                }
                            },
                            {
                                "$unwind": "$recipe_info"
                            },
                            {
                                "$lookup": {
                                    "from": "inRecipe",
                                    "localField": "recipe_info._id",
                                    "foreignField": "rid",
                                    "as": "recipe_ingredients"
                                }
                            },
                            {
                                "$unwind": "$recipe_ingredients"
                            },
                            {
                                "$lookup": {
                                    "from": "ingredient",
                                    "localField": "recipe_ingredients.id",
                                    "foreignField": "_id",
                                    "as": "ingredient_info"
                                }
                            },
                            {
                                "$project": {
                                    "date": "$date", 
                                    "recipeID": 1,
                                    "rname": "$recipe_info.rname",
                                    "instructions": "$recipe_info.instructions",
                                    "ingredient": "$ingredient_info.name",
                                    "quantity": "$recipe_ingredients.quantity",
                                    "units": "$recipe_ingredients.units",
                                    "caloriesPerGram": { "$arrayElemAt": [ "$ingredient_info.calories", 0 ] },
                                    "calories": {
                                        "$switch": {
                                            "branches": [
                                                {
                                                    "case": {"$eq": ["$recipe_ingredients.units", "grams"]},
                                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                                    }]}
                                                },
                                                {
                                                    "case": {"$eq": ["$recipe_ingredients.units", "pounds"]},
                                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                                    }, 453.59]}
                                                },
                                                {
                                                    "case": {"$eq": ["$recipe_ingredients.units", "millilitre"]},
                                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                                    }]}
                                                },
                                                {
                                                    "case": {"$eq": ["$recipe_ingredients.units", "tsp"]},
                                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                                    }, 4.26]}
                                                },
                                                {
                                                    "case": {"$eq": ["$recipe_ingredients.units", "tbsp"]},
                                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                                    }, 12.78]}
                                                },
                                                {
                                                    "case": {"$eq": ["$recipe_ingredients.units", "slice"]},
                                                    "then": {"$multiply": [{"$toDouble": "$recipe_ingredients.quantity"}, {"$toDouble": {
                                                        "$arrayElemAt": [ "$ingredient_info.calories", 0]}
                                                    }, 50]}
                                                }
                                            ],
                                            "default": 1
                                        }
                                    }
                                }
                                },
                                {
                                "$group": {
                                    "_id": {
                                        "date": "$date",
                                        "recipeID": "$recipeID",
                                        "rname": "$rname",
                                        "instructions": "$instructions"
                                    }, 
                                    "ingredients": {
                                        "$push": {
                                            "name": "$ingredient",
                                            "quantity": "$quantity",
                                            "units": "$units",
                                            "caloriesPerGram": "$caloriesPerGram",
                                            "calories": "$calories"
                                            }
                                        },
                                    "totalCalories": {"$sum": "$calories"},
                                    }
                                },
                                {
                                    "$group" : {
                                        "_id": "$_id.recipeID",
                                        "count": {"$sum": 1},
                                        "dates": {
                                            "$push": {
                                                "date": "$_id.date"
                                            }
                                        },
                                        "rname": {"$first": "$_id.rname"},
                                        "instructions": {"$first": "$_id.instructions"},
                                        "ingredients": {"$first": "$ingredients"},
                                        "totalCaloriesConsumed": {"$sum": "$totalCalories"} 
                                    }
                                },
                                {
                                    "$project": {
                                        "_id": "$_id",
                                        "count": 1,
                                        "dates": 1,
                                        "rname": 1,
                                        "instructions": 1,
                                        "ingredients": 1,
                                        "totalCaloriesConsumed": {"$round": ["$totalCaloriesConsumed", 2]}
                                    }
                                },
                                {
                                    "$sort": {
                                        "_id": 1
                                    }
                                }
                        ])
                result = [x for x in result]
                for item in result:
                    print(item)
                    print()

                mostConsumedMeal =  maxRepeatedMeal(result)
                ln = len(mostConsumedMeal)

                #Uncomment to print the items of mostConsumedMeal
                '''for item in mostConsumedMeal:
                    print(item)
                    print()'''
                
                return render_template("mostConsumedMeal.html", mostConsumedMeal=mostConsumedMeal, ln = ln)
    return render_template("mostConsumedMeal.html", mostConsumedMeal=None, ln = 0)
