from flask import Flask 
from flask_pymongo import PyMongo
import flask
import pymongo

DB_NAME = "recipeDB"

app = Flask(__name__)
conn = "mongodb://localhost:27017/recipeDB"
client = PyMongo(app, uri = conn)
global db
db = client.db

def create_app():
    app.config['SECRET_KEY'] = 'hello world'

    from .views import views 
    app.register_blueprint(views, url_prefix = '/')
        

    return app

